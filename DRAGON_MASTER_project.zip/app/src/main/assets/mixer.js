(function () {
  if (window.__ssMixer) return;
  var MD = navigator.mediaDevices;
  var origGUM = MD && MD.getUserMedia ? MD.getUserMedia.bind(MD) : null;
  var AC = window.AudioContext || window.webkitAudioContext;
  var S = { pipes: new Set(), items: {}, order: [], mics: {}, micSeq: 0, master: 1, monitor: true, monVol: 1, monCtx: null, devices: [], err: '' };

  function now() { return performance.now(); }
  function clamp(v, a, b) { v = Number(v); if (!isFinite(v)) v = a; return Math.min(b, Math.max(a, v)); }
  function monCtx() {
    if (!S.monCtx) {
      try { S.monCtx = new AC({ sampleRate: 48000 }); } catch (e) { S.monCtx = new AC(); }
    }
    if (S.monCtx.state === 'suspended') { try { S.monCtx.resume(); } catch (e) {} }
    return S.monCtx;
  }

  // ---------- library ----------
  function syncLib(list) {
    var seen = {};
    list = list.filter(function (m) { return !/\.zip$/i.test(m.name || ''); });
    list.forEach(function (m) {
      seen[m.id] = 1;
      if (!S.items[m.id]) {
        S.items[m.id] = { id: m.id, name: m.name, kind: m.kind, buf: null, loading: null, dur: 0, vol: 1, loop: false,
          playing: false, offset: 0, startedAt: 0, tok: 0, nodes: new Map(), mon: null, err: '' };
      } else { S.items[m.id].name = m.name; }
    });
    Object.keys(S.items).forEach(function (id) {
      if (!seen[id]) { stopNodes(S.items[id]); delete S.items[id]; }
    });
    S.order = list.map(function (m) { return m.id; });
  }
  function pullLib() { try { syncLib(JSON.parse(SSBridge.listMedia())); } catch (e) {} }

  function b64ToBytes(b64, out, pos) {
    var bin = atob(b64);
    for (var i = 0; i < bin.length; i++) out[pos + i] = bin.charCodeAt(i);
    return bin.length;
  }
  function load(it) {
    if (it.buf) return Promise.resolve(it.buf);
    if (it.loading) return it.loading;
    it.err = '';
    it.loading = (async function () {
      var info = JSON.parse(SSBridge.mediaInfo(it.id));
      var bytes = new Uint8Array(info.size);
      var pos = 0, idx = 0;
      while (pos < info.size) {
        var b64 = SSBridge.mediaChunk(it.id, idx++);
        if (!b64) throw new Error('read');
        pos += b64ToBytes(b64, bytes, pos);
        if ((idx & 3) === 0) await new Promise(function (r) { setTimeout(r, 0); });
      }
      var ctx = monCtx();
      var buf = await new Promise(function (res, rej) {
        var p = ctx.decodeAudioData(bytes.buffer, res, rej);
        if (p && p.catch) p.catch(rej);
      });
      it.buf = buf; it.dur = buf.duration;
      return buf;
    })();
    it.loading.catch(function () { it.err = 'decode'; it.loading = null; });
    return it.loading;
  }

  // ---------- playback ----------
  function elapsed(it) { return it.playing ? (now() - it.startedAt) / 1000 : it.offset; }
  function startPos(it) {
    var off = elapsed(it);
    if (it.loop && it.buf) off = off % it.buf.duration;
    if (it.buf && off >= it.buf.duration) off = 0;
    return off;
  }
  function startOn(it, pl) {
    if (!it.buf || !pl.mix || it.nodes.has(pl)) return;
    var ctx = pl.ctx, src = ctx.createBufferSource(), g = ctx.createGain();
    src.buffer = it.buf; src.loop = it.loop; g.gain.value = it.vol;
    src.connect(g); g.connect(pl.mix.bus);
    var entry = { src: src, g: g, tok: it.tok };
    src.onended = function () { if (it.playing && it.tok === entry.tok && !it.loop) finish(it); };
    try { src.start(0, startPos(it)); } catch (e) { return; }
    it.nodes.set(pl, entry);
  }
  function monGain(it) { return it.vol * S.master * S.monVol; }
  function startMon(it) {
    if (!S.monitor || !it.buf || it.mon) return;
    var ctx = monCtx(), src = ctx.createBufferSource(), g = ctx.createGain();
    src.buffer = it.buf; src.loop = it.loop; g.gain.value = monGain(it);
    src.connect(g); g.connect(ctx.destination);
    try { src.start(0, startPos(it)); } catch (e) { return; }
    it.mon = { src: src, g: g };
  }
  function stopMon(it) {
    if (!it.mon) return;
    try { it.mon.src.onended = null; it.mon.src.stop(); } catch (_) {}
    try { it.mon.src.disconnect(); it.mon.g.disconnect(); } catch (_) {}
    it.mon = null;
  }
  function stopNodes(it) {
    it.nodes.forEach(function (e) {
      e.src.onended = null;
      try { e.src.stop(); } catch (_) {}
      try { e.src.disconnect(); e.g.disconnect(); } catch (_) {}
    });
    it.nodes.clear();
    stopMon(it);
  }
  function finish(it) { it.playing = false; it.offset = 0; stopNodes(it); }
  function play(id) {
    var it = S.items[id]; if (!it) return;
    load(it).then(function () {
      if (it.playing) return;
      if (it.offset >= it.dur - 0.05) it.offset = 0;
      it.tok++;
      it.playing = true;
      it.startedAt = now() - it.offset * 1000;
      S.pipes.forEach(function (pl) { startOn(it, pl); });
      startMon(it);
    }).catch(function () { it.err = 'decode'; });
  }
  function pause(id) {
    var it = S.items[id]; if (!it || !it.playing) return;
    it.offset = elapsed(it); it.playing = false; stopNodes(it);
  }
  function stop(id) {
    var it = S.items[id]; if (!it) return;
    it.playing = false; it.offset = 0; stopNodes(it);
  }
  function seek(id, t) {
    var it = S.items[id]; if (!it) return;
    t = clamp(t, 0, it.dur || 0);
    if (it.playing) {
      stopNodes(it); it.tok++; it.offset = t; it.startedAt = now() - t * 1000;
      S.pipes.forEach(function (pl) { startOn(it, pl); });
      startMon(it);
    } else { it.offset = t; }
  }
  function setVol(id, v) {
    var it = S.items[id]; if (!it) return;
    it.vol = clamp(v, 0, 4);
    it.nodes.forEach(function (e) { e.g.gain.value = it.vol; });
    if (it.mon) it.mon.g.gain.value = monGain(it);
  }
  function setLoop(id, b) {
    var it = S.items[id]; if (!it) return;
    it.loop = !!b;
    it.nodes.forEach(function (e) { e.src.loop = it.loop; });
    if (it.mon) it.mon.src.loop = it.loop;
  }
  function refreshMon() {
    Object.keys(S.items).forEach(function (id) {
      var it = S.items[id];
      if (it.mon) it.mon.g.gain.value = monGain(it);
    });
  }
  function setMaster(v) {
    S.master = clamp(v, 0, 4);
    S.pipes.forEach(function (pl) { if (pl.mix) pl.mix.bus.gain.value = S.master; });
    refreshMon();
  }
  function setMonitor(b) {
    S.monitor = !!b;
    Object.keys(S.items).forEach(function (id) {
      var it = S.items[id];
      if (S.monitor && it.playing) startMon(it); else stopMon(it);
    });
  }

  // ---------- extra microphones ----------
  function attachMic(pl, m) {
    if (!pl.input || !pl.mix) return;
    var src = pl.ctx.createMediaStreamSource(m.stream), g = pl.ctx.createGain();
    g.gain.value = m.muted ? 0 : m.gain;
    src.connect(g); g.connect(pl.input);
    pl.mix.mics.set(m.id, { src: src, g: g });
  }
  function refreshDevices() {
    if (!MD || !MD.enumerateDevices) return Promise.resolve();
    return MD.enumerateDevices().then(function (d) {
      S.devices = d.filter(function (x) { return x.kind === 'audioinput'; })
        .map(function (x, i) { return { id: x.deviceId, label: x.label || ('Mic ' + (i + 1)) }; });
    }).catch(function () {});
  }
  function addMic(deviceId, label) {
    if (!origGUM) { S.err = 'mic-unsupported'; return; }
    var audio = { echoCancellation: false, noiseSuppression: false, autoGainControl: false };
    if (deviceId) audio.deviceId = { exact: deviceId };
    origGUM({ audio: audio }).then(function (stream) {
      var id = 'm' + (++S.micSeq);
      var m = { id: id, label: label || ('Mic ' + S.micSeq), stream: stream, gain: 1, muted: false };
      S.mics[id] = m;
      S.pipes.forEach(function (pl) { attachMic(pl, m); });
      S.err = '';
      refreshDevices();
    }).catch(function () { S.err = 'mic-failed'; });
  }
  function rmMic(id) {
    var m = S.mics[id]; if (!m) return;
    S.pipes.forEach(function (pl) {
      var e = pl.mix && pl.mix.mics.get(id);
      if (e) { try { e.src.disconnect(); e.g.disconnect(); } catch (_) {} pl.mix.mics.delete(id); }
    });
    try { m.stream.getTracks().forEach(function (t) { t.stop(); }); } catch (_) {}
    delete S.mics[id];
  }
  function applyMic(m) {
    S.pipes.forEach(function (pl) {
      var e = pl.mix && pl.mix.mics.get(m.id);
      if (e) e.g.gain.value = m.muted ? 0 : m.gain;
    });
  }

  // ---------- pipeline hooks (called from injector.js) ----------
  function attach(pl) {
    if (!pl || !pl.ctx || !pl.dst || pl.mix) return;
    var ctx = pl.ctx;
    var bus = ctx.createGain(); bus.gain.value = S.master;
    var lim = ctx.createDynamicsCompressor();
    lim.threshold.value = -2; lim.knee.value = 0; lim.ratio.value = 20; lim.attack.value = 0.002; lim.release.value = 0.08;
    bus.connect(lim); lim.connect(pl.dst);
    pl.mix = { bus: bus, lim: lim, mics: new Map() };
    S.pipes.add(pl);
    Object.keys(S.mics).forEach(function (id) { attachMic(pl, S.mics[id]); });
    Object.keys(S.items).forEach(function (id) { var it = S.items[id]; if (it.playing) startOn(it, pl); });
  }
  function detach(pl) {
    S.pipes.delete(pl);
    Object.keys(S.items).forEach(function (id) {
      var it = S.items[id], e = it.nodes.get(pl);
      if (e) { e.src.onended = null; try { e.src.stop(); } catch (_) {} it.nodes.delete(pl); }
    });
  }

  // ---------- ZIP extension runtime (page side) ----------
  S.boot = Math.random().toString(36).slice(2); S.xs = {}; S.xr = {};
  var X = window.__ssX = { ex: {} };
  function jc(v) { try { return v === undefined ? undefined : JSON.parse(JSON.stringify(v)); } catch (e) { return undefined; } }
  function rxEsc(s) { return s.replace(/[.+?^${}()|[\]\\]/g, '\\$&'); }
  X.m = function (pats) {
    if (!pats || !pats.length) return true;
    var href = location.href;
    return pats.some(function (p) {
      if (p === '<all_urls>') return /^https?:/.test(href);
      var m = /^(\*|https?|file|ftp):\/\/([^\/]*)(\/.*)$/.exec(p); if (!m) return false;
      var sch = m[1] === '*' ? 'https?' : m[1];
      var host = m[2] === '*' ? '[^/]*' : (m[2].indexOf('*.') === 0 ? '([^/]*\\.)?' + rxEsc(m[2].slice(2)) : rxEsc(m[2]));
      var path = rxEsc(m[3]).replace(/\*/g, '.*');
      try { return new RegExp('^' + sch + ':\\/\\/' + host + path + '$').test(href); } catch (e) { return false; }
    });
  };
  X.deliver = function (E, msg, sender, done) {
    var ls = E.msgL.slice();
    if (!ls.length) { done(undefined, true); return; }
    var answered = false, pending = false;
    function send(r) { if (answered) return; answered = true; done(jc(r)); }
    ls.forEach(function (f) {
      try {
        var r = f(jc(msg), sender, send);
        if (r === true) pending = true;
        else if (r && typeof r.then === 'function') { pending = true; r.then(send, function () {}); }
      } catch (e) {}
    });
    if (!answered && !pending) setTimeout(function () { if (!answered) done(undefined); }, 0);
  };
  X.msg = function (id, reqId, msg) {
    var E = X.ex[id];
    if (!E) { S.xr[reqId] = { none: 1 }; return; }
    X.deliver(E, msg, { id: id, url: location.href, tab: { id: 1, url: location.href } }, function (r, none) { S.xr[reqId] = { r: r === undefined ? null : r, none: !!none }; });
  };
  X.store = function (id, data, ch) {
    var E = X.ex[id]; if (!E) return;
    E.store = jc(data) || {};
    E.chgL.forEach(function (f) { try { f(ch || {}, 'local'); } catch (e) {} });
  };
  X.kill = function (id, dead) { var E = X.ex[id]; if (E) E.dead = !!dead; };
  X.res = {};
  X.reg = function (id, path, fn) { (X.res[id] = X.res[id] || {})[path] = fn; };
  (function () {
    var ssRe = /^ssext:\/\/([^\/]+)\/(.*)$/;
    function runRes(el, v) {
      var m = ssRe.exec(String(v));
      setTimeout(function () {
        var f = (X.res[m[1]] || {})[m[2]];
        try { if (f) f(); } catch (e) {}
        try { el.dispatchEvent(new Event(f ? 'load' : 'error')); } catch (e) {}
      }, 0);
    }
    try {
      var d = Object.getOwnPropertyDescriptor(HTMLScriptElement.prototype, 'src');
      if (d && d.set) {
        Object.defineProperty(HTMLScriptElement.prototype, 'src', {
          configurable: true, enumerable: d.enumerable, get: d.get,
          set: function (v) { if (ssRe.test(String(v))) runRes(this, v); else d.set.call(this, v); }
        });
      }
      var sa = Element.prototype.setAttribute;
      Element.prototype.setAttribute = function (n, v) {
        if (this instanceof HTMLScriptElement && String(n).toLowerCase() === 'src' && ssRe.test(String(v))) { runRes(this, v); return; }
        return sa.apply(this, arguments);
      };
    } catch (e) {}
  })();
  function xevt(list) {
    return {
      addListener: function (f) { if (typeof f === 'function' && list.indexOf(f) < 0) list.push(f); },
      removeListener: function (f) { var i = list.indexOf(f); if (i >= 0) list.splice(i, 1); },
      hasListener: function (f) { return list.indexOf(f) >= 0; }
    };
  }
  X.ctx = function (id, store, manifest) {
    if (X.ex[id]) return X.ex[id];
    var E = X.ex[id] = { id: id, store: jc(store) || {}, rev: 0, msgL: [], chgL: [], manifest: manifest || {}, ran: {} };
    var sender = { id: id, url: location.href, tab: { id: 1, url: location.href } };
    function P(cb, fn) {
      if (typeof cb === 'function') { try { fn(cb); } catch (e) {} return undefined; }
      return new Promise(function (res) { fn(res); });
    }
    function pick(keys) {
      var out = {}, st = E.store;
      if (keys == null) return jc(st);
      if (typeof keys === 'string') keys = [keys];
      if (Array.isArray(keys)) keys.forEach(function (k) { if (k in st) out[k] = jc(st[k]); });
      else Object.keys(keys).forEach(function (k) { out[k] = (k in st) ? jc(st[k]) : keys[k]; });
      return out;
    }
    function commit(ch) {
      if (!Object.keys(ch).length) return;
      var cur = S.xs[id] || { rev: 0, ch: {} };
      Object.keys(ch).forEach(function (k) { cur.ch[k] = (k in E.store) ? { v: jc(E.store[k]) } : { del: 1 }; });
      cur.rev = ++E.rev; S.xs[id] = cur;
      setTimeout(function () { E.chgL.slice().forEach(function (f) { try { f(ch, 'local'); } catch (e) {} }); }, 0);
    }
    function area() {
      return {
        get: function (k, cb) { return P(cb, function (c) { setTimeout(function () { c(pick(k)); }, 0); }); },
        set: function (o, cb) {
          return P(cb, function (c) {
            var ch = {}; Object.keys(o || {}).forEach(function (k) { ch[k] = { oldValue: E.store[k], newValue: jc(o[k]) }; E.store[k] = jc(o[k]); });
            commit(ch); setTimeout(c, 0);
          });
        },
        remove: function (k, cb) {
          return P(cb, function (c) {
            var ch = {}; (Array.isArray(k) ? k : [k]).forEach(function (x) { if (x in E.store) { ch[x] = { oldValue: E.store[x] }; delete E.store[x]; } });
            commit(ch); setTimeout(c, 0);
          });
        },
        clear: function (cb) {
          return P(cb, function (c) {
            var ch = {}; Object.keys(E.store).forEach(function (x) { ch[x] = { oldValue: E.store[x] }; }); E.store = {};
            commit(ch); setTimeout(c, 0);
          });
        },
        getBytesInUse: function (k, cb) { cb = typeof k === 'function' ? k : cb; return P(cb, function (c) { c(0); }); }
      };
    }
    var noop = function () { var a = arguments, cb = a[a.length - 1]; if (typeof cb === 'function') setTimeout(function () { cb(); }, 0); };
    var ch = {};
    ch.runtime = {
      id: id, lastError: null,
      getURL: function (p) { return 'ssext://' + id + '/' + String(p || '').replace(/^\//, ''); },
      getManifest: function () { return jc(E.manifest); },
      sendMessage: function () {
        var a = [].slice.call(arguments), cb = typeof a[a.length - 1] === 'function' ? a.pop() : null;
        if (typeof a[0] === 'string' && a.length > 1) a.shift();
        return P(cb, function (c) { X.deliver(E, a[0], sender, function (r) { c(r); }); });
      },
      onMessage: xevt(E.msgL), onInstalled: xevt([]), onStartup: xevt([]),
      connect: function () { return { postMessage: noop, disconnect: noop, onMessage: xevt([]), onDisconnect: xevt([]) }; }
    };
    ch.storage = { local: area(), sync: area(), session: area(), onChanged: xevt(E.chgL) };
    ch.tabs = {
      query: function (q, cb) { return P(cb, function (c) { c([{ id: 1, active: true, windowId: 1, url: location.href }]); }); },
      sendMessage: function () {
        var a = [].slice.call(arguments), cb = typeof a[a.length - 1] === 'function' ? a.pop() : null;
        return P(cb, function (c) { X.deliver(E, a[1], sender, function (r) { c(r); }); });
      },
      create: noop, update: noop, onUpdated: xevt([]), onActivated: xevt([])
    };
    ch.i18n = { getMessage: function () { return ''; }, getUILanguage: function () { return 'en'; } };
    ch.action = ch.browserAction = ch.pageAction = { setBadgeText: noop, setBadgeBackgroundColor: noop, setIcon: noop, setTitle: noop, onClicked: xevt([]) };
    ch.scripting = { executeScript: function (o, cb) { return P(cb, function (c) { c([]); }); } };
    ch.permissions = { contains: function (p, cb) { return P(cb, function (c) { c(true); }); }, request: function (p, cb) { return P(cb, function (c) { c(true); }); } };
    E.chrome = ch;
    E.gp = new Proxy(window, {
      get: function (t, k) {
        if (k === 'chrome' || k === 'browser') return ch;
        if (k === 'postMessage' && E.dead) return function () {};
        var v = t[k];
        return (typeof v === 'function' && !/^[A-Z]/.test(String(k))) ? v.bind(t) : v;
      },
      set: function (t, k, v) { t[k] = v; return true; },
      has: function () { return true; }
    });
    return E;
  };

  // ---------- state + commands ----------
  function snapshot() {
    var items = S.order.map(function (id) {
      var it = S.items[id]; if (!it) return null;
      var off = elapsed(it);
      if (it.dur && it.loop) off = off % it.dur;
      if (it.dur && off > it.dur) off = it.dur;
      return { id: id, playing: it.playing, loading: !!(it.loading && !it.buf), off: off, dur: it.dur || 0, vol: it.vol, loop: it.loop, err: it.err };
    }).filter(Boolean);
    var mics = Object.keys(S.mics).map(function (id) {
      var m = S.mics[id]; return { id: id, label: m.label, gain: m.gain, muted: m.muted };
    });
    return { items: items, mics: mics, devices: S.devices, master: S.master, monitor: S.monitor, monVol: S.monVol,
      call: S.pipes.size > 0, err: S.err, t: Date.now(), boot: S.boot, xs: S.xs, xr: S.xr, diag: (function () { try { return window.__ssDiag ? window.__ssDiag() : null; } catch (e) { return null; } })() };
  }
  function cmd(c) {
    if (!c) return;
    switch (c.t) {
      case 'lib': syncLib(c.items || []); break;
      case 'xAck': (c.ids || []).forEach(function (k) { if (k.indexOf('x:') === 0) { var q = k.split(':'), cur = S.xs[q[1]]; if (cur && cur.rev <= Number(q[2])) delete S.xs[q[1]]; } else delete S.xr[k]; }); break;
      case 'play': play(c.id); break;
      case 'pause': pause(c.id); break;
      case 'stop': stop(c.id); break;
      case 'seek': seek(c.id, c.v); break;
      case 'vol': setVol(c.id, c.v); break;
      case 'loop': setLoop(c.id, c.v); break;
      case 'master': setMaster(c.v); break;
      case 'monitor': setMonitor(c.v); break;
      case 'monVol': S.monVol = clamp(c.v, 0, 1.5); refreshMon(); break;
      case 'refresh': refreshDevices(); break;
      case 'addMic': addMic(c.deviceId, c.label); break;
      case 'rmMic': rmMic(c.id); break;
      case 'micGain': if (S.mics[c.id]) { S.mics[c.id].gain = clamp(c.v, 0, 10); applyMic(S.mics[c.id]); } break;
      case 'micMute': if (S.mics[c.id]) { S.mics[c.id].muted = !!c.v; applyMic(S.mics[c.id]); } break;
    }
  }

  window.__ssMixer = { attach: attach, detach: detach, cmd: cmd, snapshot: snapshot };
  pullLib();
  refreshDevices();
  setInterval(refreshDevices, 5000);
  setInterval(function () { try { SSBridge.mixerState(JSON.stringify(snapshot())); } catch (e) {} }, 500);
})();
