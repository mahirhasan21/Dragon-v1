(function () {
  if (window.__ssBridgeInit) return;
  window.__ssBridgeInit = true;
  var D = {
    enabled: true, gainDb: 84, thresholdDb: -60, knee: 40, ratio: 20, attack: 0.0001, release: 0.03,
    lowShelfDb: 14, presenceDb: 20, highShelfDb: 16, limiterDb: -0.1, drive: 1.8, loudness: 20.0,
    maxBoost: 5000, sustain: true, sustainTargetDb: -2, sustainMaxGain: 64, forceRawMic: true,
    punch: 6, listenGain: 6, listenClarity: 6, listenBass: 4, listenPunch: 5, micBoost: 4
  };
  function load() {
    var s = null;
    try { s = JSON.parse(SSBridge.getConfig()); } catch (e) {}
    var out = {}, k;
    for (k in D) out[k] = D[k];
    if (s && s.forceRawMic !== undefined) for (k in s) out[k] = s[k];
    return out;
  }
  var foreignAt = 0;
  window.addEventListener('message', function (e) {
    if (e.source === window && e.data && e.data.type === 'MIC_MAXIMIZER_CONFIG' && !e.data.ss) foreignAt = Date.now();
  });
  function push() {
    if (Date.now() - foreignAt < 9000) return; // a ZIP extension is controlling the mic settings
    window.postMessage({ type: 'MIC_MAXIMIZER_CONFIG', payload: load(), ss: 1 }, '*');
  }
  window.__ssPush = push;
  window.addEventListener('message', function (e) {
    if (e.source === window && e.data && e.data.type === 'MIC_MAXIMIZER_READY') {
      try { SSBridge.ready(); } catch (_) {}
      push();
    }
  });
  setInterval(push, 3500);
  setInterval(function () { if (window.__micMaxInjectorReady) { try { SSBridge.ready(); } catch (_) {} } }, 5000);
})();
